package ar.com.codoacodo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TurnosConsultorioApplication {

	public static void main(String[] args) {
		SpringApplication.run(TurnosConsultorioApplication.class, args);
	}

}
