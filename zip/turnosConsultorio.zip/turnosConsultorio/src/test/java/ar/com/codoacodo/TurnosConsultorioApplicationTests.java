package ar.com.codoacodo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurnosConsultorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
